######################################################
# ex_AFFfit.r - Nov/05/2016				#
# Script created by Janet Kim			#
# Contents:					#
# Example of how to use "datagenALL.r" and "AFFfit.r"	#
# Fig 1. in the main paper				#
######################################################
library(MASS); library(Matrix); library(refund); library(mgcv)
source("datagenALL.r"); source("AFFfit.r")

# Scenario: True model=complex non-linear, error_type=4, sampling design=sparse
data = datagen(n=150, m_s=81, m_t=101, 
	         mi_low.x=35, mi_up.x=44, 				# 35~44pts/subj in covariate 
                        mi_low.y=45, mi_up.y=55, 				# 45~55pts/subj in response
                        sampling="sparse", model_opt=3, error_type=4,
	         tau=0.25,	      					# WN var in covariate 
	         sig2noise=0.09,					# WN var in response
	         seed=10
	         )
y = data$Yeval[1:100,]; w = data$Weval[1:100,] 				# training data
testdata=list(Wfull = data$Wfull[101:150,], Ytrue = data$Int_Ffull[101:150,]) 	# test data

# Fit AFF-PC:
affpc = AFF(y=y, w=w, pve.x=0.95, pve.y=0.95, nbasis=c(7,7), fit_opt="AFF-PC", testdata=testdata)
affpc_est = affpc$Yfit   # fitted curves from training data
affpc_pred = affpc$Ypred # predcted curvees from test data

# Fit AFF-S:
options(warn=-1) # Suppress warnings!
affs = AFF(y=y, w=w, pve.x=0.95, pve.y=0.95, nbasis=c(6,5,5), fit_opt="AFF-S", testdata=testdata)
affs_est = affpc$Yfit   # fitted curves from training data
affs_pred = affpc$Ypred # predcted curvees from test data

# Fit FLM:
options(warn=-1) # Suppress warnings!
flm = AFF(y=y, w=w, pve.x=0.95, pve.y=0.95, nbasis=c(7,7), fit_opt="FLM", testdata=testdata)
flm_est = affpc$Yfit   # fitted curves from training data
flm_pred = affpc$Ypred # predcted curvees from test data


#########################
# Fig. 1 in the main paper #
#########################
phi1 = function(t){rep(1, length(t))}
phi2 = function(t){sqrt(2)*sin(2*pi*t)}
phi3 = function(t){sqrt(2)*cos(2*pi*t)}
phi4 = function(t){sqrt(2)*sin(4*pi*t)}
phi5 = function(t){sqrt(2)*cos(4*pi*t)}
G1 = function(x,s){x*s}
G2 = function(x,s){4-2*(x/5)^2-s/.1}
G3 = function(x,s){sin(2-x-s/.5)}
G4 = function(x,s){2*cos(pi*s)*x}
G5 = function(x,s){exp(-x^2/5^2-(s-.5)^2/.3^2)-0.5}

# 3D surface of complex non-linear case
F3_1 = function(x,s){
  r = phi1(0.05)*G1(x,s) + phi2(0.05)*G2(x,s) + phi3(0.05)*G3(x,s) + phi4(0.05)*G4(x,s) + phi5(0.05)*G5(x,s)
}
F3_2 = function(x,s){
  r = phi1(0.5)*G1(x,s) + phi2(0.5)*G2(x,s) + phi3(0.5)*G3(x,s) + phi4(0.5)*G4(x,s) + phi5(0.5)*G5(x,s)
}
F3_3 = function(x,s){
  r = phi1(1)*G1(x,s) + phi2(1)*G2(x,s) + phi3(1)*G3(x,s) + phi4(1)*G4(x,s) + phi5(1)*G5(x,s)
}
x <- seq(-4, 4, len=19); s <- seq(0, 1, len=19)

# leftmost panel
z_1 <- outer(x, s, F3_1)
op <- par(bg = "white")
persp(x, s, z_1, theta = -130, phi = 20, col = "gray88", ticktype = "detailed", zlim=c(-7,6.5),
      cex.lab=1.8, xlab = "x", ylab="s", zlab = "F(x,s,t=0.05)") -> res_1
lines (trans3d(x, 0.6, F3_1(x,0.6),pmat = res_1), lwd=2.5)
# middle panel
z_2 <- outer(x, s, F3_2)
op <- par(bg = "white")
persp(x, s, z_2, theta = -130, phi = 20, col = "gray88", ticktype = "detailed", zlim=c(-7,6.5),
      cex.lab=1.8, xlab = "x", ylab="s", zlab = "F(x,s,t=0.5)") -> res_2
lines (trans3d(x, 0.6, F3_2(x,0.6),pmat = res_2), lwd=2.5)
# rightmost panel
z_3 <- outer(x, s, F3_3)
op <- par(bg = "white")
persp(x, s, z_3, theta = -130, phi = 20, col = "gray88", ticktype = "detailed", zlim=c(-7,6.5), 
      cex.lab=1.8, xlab = "x", ylab="s", zlab = "F(x,s,t=1)") -> res_3
lines (trans3d(x, 0.6, F3_3(x,0.6),pmat = res_3), lwd=2.5)