######################################################
# datagenALL.r - Jan/06/2016			#
# Script created by Janet Kim			#
# Contents:					#
# (i)	X					#
# (ii)	G1, G2, G3, G4, G5, Int_G			#
# (iii)	Phi					#
# (iv)	Int_F					#
# (v)	build.AR, Error_resp			# 
# (vi)	datagen, Test.datagen, BS.datagen		#
#						#
# @ Sample size in the data:				#
#   n subjects					#
#   m_s observation points per subject for covariate 	#
#   m_t observation points per subject for response 	#
######################################################

# Functional Covariate without errors
X = function(n, s, tau=0){ # dim(s) = m-by-1
  m = length(s)
  a0 = rnorm(n, sd=1)
  a1 = rnorm(n, 0, sd=0.5)
  a2 = rnorm(n, 0, sd=0.25)
  ones = rep(1,m)
  phi1 = sqrt(2)*sin(pi*s)            			# m-by-1
  phi2 = sqrt(2)*cos(pi*s)				# m-by-1
  X.true = a0%*%t(ones)+a1%*%t(phi1)+a2%*%t(phi2)	# n-by-m  
  error.x = mvrnorm(n, mu=rep(0,m), Sigma=tau*diag(m)) 	# n-by-m
  W = X.true + error.x
  result = list(X.true = X.true, W = W)
  result
}


G1 = function(x,s){x*s}
G2 = function(x,s){4-2*(x/5)^2-s/.1}
G3 = function(x,s){sin(2-x-s/.5)}
G4 = function(x,s){2*cos(pi*s)*x}
G5 = function(x,s){exp(-x^2/5^2-(s-.5)^2/.3^2)-0.5}
Int_G = function(xrep,srep, G){rowMeans(G(xrep, srep))}


# Orthogonal Basis function of t
phi = function(t){
  phi1 = rep(1, length(t))
  phi2 = sqrt(2)*sin(2*pi*t)
  phi3 = sqrt(2)*cos(2*pi*t)
  phi4 = sqrt(2)*sin(4*pi*t)
  phi5 = sqrt(2)*cos(4*pi*t)  
  result = list(phi1 = phi1, phi2 = phi2, phi3 = phi3, phi4 = phi4, phi5 = phi5)
}


# Int F(x,s,t) ds over s; dim(xrep) = dim(srep) = dim(trep) = n-by-m
Int_F = function(xrep, srep, t, model_opt=1){
  if (model_opt==1){
    out = Int_G(xrep, srep, G1)%*%t(phi(t)$phi2) + 
      Int_G(xrep, srep, G4)%*%t(phi(t)$phi3)
  }
  if (model_opt==2){
    out = Int_G(xrep, srep, G1)%*%t(phi(t)$phi1) + 
      Int_G(xrep, srep, G2)%*%t(phi(t)$phi2)
  }
  if (model_opt==3){
    out = Int_G(xrep, srep, G1)%*%t(phi(t)$phi1)+
      Int_G(xrep, srep, G2)%*%t(phi(t)$phi2)+
      Int_G(xrep, srep, G3)%*%t(phi(t)$phi3)+
      Int_G(xrep, srep, G4)%*%t(phi(t)$phi4)+
      Int_G(xrep, srep, G5)%*%t(phi(t)$phi5)
  }
  out
}


# Build AR(1) covariance matrix for the random errors
build.AR = function(m_t, sigma2, rho){ 
  power = 0:(m_t-1)
  H= abs(outer(power, power, "-"))			# m_t-by-m_t
  V = sigma2*(rho^H)                			# m_t-by-m_t
  V
}

# Create Random Errors
Error_resp = function(n, m_t, t, error_type, sig2noise, rho){ # dim(t) = m_t-by-1
  Error0 = mvrnorm(n, mu=rep(0,m_t), Sigma=sig2noise*diag(m_t))
  
  if (error_type==1) {# Independent
    Error = Error0
  }
  if (error_type==2) {# AR(1) + WN
    Error.temp = mvrnorm(n, mu=rep(0,m_t), Sigma=build.AR(m_t, sig2noise, rho))
    Error = Error.temp+ Error0
  }
  if (error_type==3) {# KL Expansion + WN
    x1i = rnorm(n,0, sd=0.15)
    x2i = rnorm(n,0,sd=0.1)
    ones = rep(1,m_t)
    Error = x1i%*%t(ones)+x2i%*%t(sqrt(2)*sin(2*pi*t))+ Error0
  }
  if (error_type==4) {# KL Expansion + WN
    x1i = rnorm(n,0, sd=0.15)
    x2i = rnorm(n,0,sd=0.1)
    ones = rep(1,m_t)
    Error = x1i%*%t(sqrt(2)*cos(2*pi*t))+x2i%*%t(sqrt(2)*sin(4*pi*t))+ Error0
  }
  Error						# n-by-m_t
}


# Generate training data set 
datagen = function(n, m_s, m_t, mi_low.x=NULL, mi_up.x=NULL, 
                   mi_low.y=NULL, mi_up.y=NULL, sampling, model_opt=1, error_type, 
                   tau, sig2noise, rho=NULL, seed){
  set.seed(seed)
  # Time points
  s = seq(0, 1, len=m_s)
  t = seq(0, 1, len=m_t)
  srep = matrix(rep(s,n), nrow=n, byrow=TRUE) 
  
  data = X(n,s, tau=tau)
  Xfull = data$X.true			 	# True Functional Covariate; n-by-m_s
  Wfull = data$W  					# Noisy Covariate; n-by-m_s
  Error.full = Error_resp(n,m_t,t,error_type,sig2noise,rho)  # n-by-m_t
  
  if (sampling == "dense"){
    Xeval <- Xfull
    Weval <- Wfull
    Error.eval <- Error.full
  }
  if (sampling == "sparse"){
    Xeval = NA*Xfull
    Weval = NA*Wfull
    Error.eval = NA*Error.full
    mi.x = sample(mi_low.x:mi_up.x, n, replace=TRUE)
    mi.y = sample(mi_low.y:mi_up.y, n, replace=TRUE)
    for (i in 1:n){
      ind.x = sample(1:m_s, mi.x[i], replace=FALSE)
      ind.y = sample(1:m_t, mi.y[i], replace=FALSE)
      Xeval[i, ind.x] = Xfull[i, ind.x]
      Weval[i, ind.x] = Wfull[i, ind.x]
      Error.eval[i, ind.y] = Error.full[i, ind.y]
    }
  }
  Int_Ffull = Int_F(Xfull, srep, t, model_opt)  		# n-by-m_t  
  Yfull = Int_Ffull + Error.full                			# n-by-m_t
  Yeval = Int_Ffull + Error.eval	            			# n-by-m_t
  
  result = list(Xfull = Xfull, Xeval = Xeval, Wfull = Wfull, Weval = Weval, Int_Ffull = Int_Ffull,
                Error.full = Error.full, Error.eval = Error.eval, 
                Yfull = Yfull, Yeval = Yeval) 
}

BS.datagen = function(y, w, w2=NULL, B){
  n = nrow(y)
  # bootstrap the subjects:
  y.bs = w.bs = w2.bs = as.list(NULL)
  if (length(w2)==0){
  	for (b in 1:B){
  	  set.seed(b^2+50)
  	  ind.n = sample(c(1:n), n, replace = TRUE)    	# Resample subject index
  	  y.bs[[b]] = y[ind.n,]; w.bs[[b]] = w[ind.n,]
  	}
 } else{ 
  	for (b in 1:B){ 
	  set.seed(b^2+50) 
    	  ind.n = sample(c(1:n), n, replace = TRUE)    	# Resample subject index
    	  y.bs[[b]] = y[ind.n,]; w.bs[[b]] = w[ind.n,]; w2.bs[[b]] = w2[ind.n]
  	}
}
result = list(y.bs = y.bs, w.bs = w.bs, w2.bs = w2.bs)
}