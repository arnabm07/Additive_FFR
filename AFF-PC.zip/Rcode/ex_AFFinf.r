######################################################
# ex_AFFinf.r - Nov/06/2016				#
# Script created by Janet Kim			#
# Contents:					#
# Example of how to use "datagenALL.r" and "AFFinf.r". 	#
# Code example of visualizing prediction interval.	#
######################################################
library(MASS); library(Matrix); library(refund); library(mgcv)
source("datagenALL.r"); source("AFFinf.r")

# Scenario: True model=complex non-linear, error_type=4, sampling design=sparse
data = datagen(n=200, m_s=81, m_t=101, 
               mi_low.x=35, mi_up.x=44, 				# 35~44pts/subj in covariate 
               mi_low.y=45, mi_up.y=55, 				# 45~55pts/subj in response
               sampling="sparse", model_opt=3, error_type=4,
               tau=0.25,	      					# WN var in covariate 
               sig2noise=0.09,					# WN var in response
               seed=10
)
y = data$Yeval[1:100,]; w = data$Weval[1:100,] 				# training data
testdata=list(Wfull = data$Wfull[101:200,], Yfull = data$Yfull[101:200,]) 	# test data

options(warn=-1) # Suppress warnings!
out = Pred_inf(y=y, w=w, pve.x=0.95, pve.y=0.95, nbasis = c(7,7), testdata=testdata, B=100)
# Results:
Ypred <- out$Ypred 		# Predicted curves
VarYp <- out$VarYp 		# Prediction variance
ACPp <- out$ACPp   		# ACP at nominal levels of 0.85, 0.90, and 0.95


# Plot 95% point-wise prediction interval:
Var.mat = matrix(VarYp, nrow= nrow(data$Yfull[101:200,]), ncol=ncol(data$Yfull[101:200,]), byrow=TRUE)
Std.mat = sqrt(Var.mat)
MOE = qnorm(1-0.05/2)*Std.mat       	# margin of error
llim = Ypred-MOE                    	# lower limit; ntest-by-m_t
ulim = Ypred+MOE  			# upper limit; ntest-by-m_t

m_t = 101
i=1				# single subject from test data.
plot(seq(0,1,len=m_t), testdata$Yfull[i,], col = "red", ylim = c(min(llim[i,]), max(ulim[i,])),
       xlab="t", ylab="Y(t)", main= paste("Prediction interval for", "subject", i))
lines(seq(0,1,len=m_t), Ypred[i,])
lines(seq(0,1,len=m_t), llim[i,], lty="dotted")
lines(seq(0,1,len=m_t), ulim[i,], lty="dotted")