######################################################
# GAFFR_inf.r - Nov/05/2016				#
# Script created by Janet Kim              		#
# Contents:                     				#
# 1) Pred_inf (main function)				#
# 2) AFF_bs (main function)				#
# 3) G, var.psi, model.Var, ACP (ancillary functions)	#
######################################################

Pred_inf = function(y, w, pve.x, pve.y, nbasis = c(7,7), testdata, B){
  n = nrow(y); m_t = ncol(y); m_s = ncol(w); ntest = nrow(testdata$Wfull)
  s = seq(0, 1, len=m_s); srep.test = matrix(s, nrow=ntest, ncol=m_s, byrow=TRUE)
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions         					# m_t-by-npc.y
  y.mu = matrix(y.sm$mu, nrow=n, ncol=m_t, byrow=TRUE)
  y.mu.test = matrix(y.sm$mu, nrow=ntest, ncol=m_t, byrow=TRUE)
  psi = y.sm$scores                   					# n-by-npc.y
  psi.vec = as.vector(y.sm$scores)                      				# n*npc.y-by-1
  psi_k = psi[,1]                               					# n-by-1; will be used in Step0
  npc.y = y.sm$npc
  
  # Smooth covariate
  w.sm = fpca.sc(w, pve=pve.x, var=TRUE) 				# Smoothing for training data
  xtest.sm = fpca.sc(w, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat	# Smoothing for test data
  w.eval = w.sm$evalues                     					# npc.x-by-1
  w.efunc = w.sm$efunctions         					# m_s-by-npc.x
  
  # Peform transformation of covariate
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }        	# m_s-by-1
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu , scale = sqrt(sig2.hat))	# training data; n-by-m_s
  wtest = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat))     	# test data; ntest-by-m_s 
  
  # Step0: Pre-fit
  prefit <- fgam(psi_k ~ 0 + af(X = xhat.tr, basistype = "te", presmooth = FALSE, Qtransform = FALSE,
                                	splinepars = list(k = nbasis)),
                        method = "REML")
  Z = Px = Ps = as.list(NULL)
  Z[[1]] <- model.matrix(prefit)
  Px[[1]] <- prefit$smooth[[1]]$S[[1]]; Ps[[1]] <- prefit$smooth[[1]]$S[[2]]
  
  # Obtain Design matrix for the test data
  Z0 = as.list(NULL)    
  L.test = matrix(prefit$fgam$ft[[1]]$L[1,], nrow=ntest, ncol=m_s, byrow=TRUE)
  Z0[[1]] <- predict.gam(prefit, 
                         newdata=list(xhat.tr.omat = wtest, xhat.tr.tmat = srep.test, L.xhat.tr= L.test), 
                         type="lpmatrix")
  
  # Step1: Joint fit using gam()
  BigZ <- as.matrix(bdiag(rep(Z, npc.y)))
  BigZ0 <- as.matrix(bdiag(rep(Z0, npc.y)))
  BigPx <- as.matrix(bdiag(rep(Px, npc.y)))
  BigPs <- as.matrix(bdiag(rep(Ps, npc.y)))
  fit <- gam(psi.vec ~ (BigZ-1), paraPen=list(BigZ=list(BigPx, BigPs)), method = "REML")      
  pred <- BigZ0%*%fit$coefficients
  
  # Estimation / Prediction
  Yfit = y.mu + matrix(fit$fitted.values, ncol=npc.y)%*%t(y.efunc)
  Ypred = y.mu.test + matrix(pred, ncol=npc.y)%*%t(y.efunc)
  
  # Estimation Variance: apply boostrap procedure
  BSdata = BS.datagen(y, w, w2=NULL, B)
  BSfit = lapply(c(1:B), function(b) AFF_bs(BSdata$y.bs[[b]], BSdata$w.bs[[b]], pve.x = pve.x, pve.y = pve.y, nbasis = nbasis, testdata, b))
  BS.VarYp = Reduce('+', lapply(c(1:B), function (b) BSfit[[b]]$VarYp))/B 	# n*m_t-by-1
  BS.Ypred = NULL
  for (b in 1:B) { BS.Ypred = cbind(BS.Ypred, as.vector(t(BSfit[[b]]$Ypred)))} 	# ntest*m_t-by-B
  # Apply iterated expectations and variance formula
  VarYp = BS.VarYp + apply(BS.Ypred, 1, var)   				# ntest*m_t-by-1
  
  # ACPp for predicted response:
  ACPp85 = ACP(testdata$Yfull, Ypred, VarYp, 0.15)
  ACPp90 = ACP(testdata$Yfull, Ypred, VarYp, 0.10)
  ACPp95 = ACP(testdata$Yfull, Ypred, VarYp, 0.05)
  ACPp = c(ACPp85, ACPp90, ACPp95)
  
  result = list(Yfit = Yfit, Ypred = Ypred, VarYp = VarYp, ACPp = ACPp)
}

AFF_bs = function(y.bs, w.bs, pve.x, pve.y, nbasis = c(7,7), testdata, b){
  # This function computes prediction variance from each bootstrap sample!
  # y.bs:      response profiles in a bootstrap data set
  # w.bs:      noisy covariate in a bootstrap data set
  n = nrow(y.bs); m_t = ncol(y.bs); m_s = ncol(w.bs); ntest = nrow(testdata$Wfull)
  s = seq(0, 1, len=m_s); srep.test = matrix(s, nrow=ntest, ncol=m_s, byrow=TRUE) 
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y.bs, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions         					# m_t-by-npc.y
  y.mu = matrix(y.sm$mu, nrow=n, ncol=m_t, byrow=TRUE)
  y.mu.test = matrix(y.sm$mu, nrow=ntest, ncol=m_t, byrow=TRUE)
  psi = y.sm$scores                   					# n-by-npc.y
  psi.vec = as.vector(psi)                      					# n*npc.y-by-1
  psi_k = psi[,1]                               					# n-by-1
  npc.y = y.sm$npc
  
  # Smooth covariate
  w.sm = fpca.sc(w.bs, pve=pve.x, var=TRUE)     				# n-by-m_s
  w.eval = w.sm$evalues                     					# npc.x-by-1
  w.efunc = w.sm$efunctions         					# m_s-by-npc.x
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu, scale = sqrt(sig2.hat))    # n-by-m_s
  
  # Peform transformation on test data set
  xtest.sm = fpca.sc(w.bs, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat
  xtest.sm.tr = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat))  
  
  prefit <- fgam(psi_k ~ 0 + af(X = xhat.tr, basistype = "te", presmooth = FALSE, Qtransform = FALSE,
                                	 splinepars = list(k = nbasis)),
                        method = "REML")
  Zb = Px = Ps = as.list(NULL)
  Zb[[1]] <- model.matrix(prefit)
  Px[[1]] <- prefit$smooth[[1]]$S[[1]]; Ps[[1]] <- prefit$smooth[[1]]$S[[2]]
  
  # Obtain Design matrix for the test data
  Z0 = as.list(NULL)
  L.test = matrix(prefit$fgam$ft[[1]]$L[1,], nrow=ntest, ncol=m_s, byrow=TRUE)
  Z0[[1]] <- predict.gam(prefit, 
                         newdata=list(xhat.tr.omat = xtest.sm.tr, xhat.tr.tmat = srep.test, L.xhat.tr= L.test), 
                         type="lpmatrix")
  
  # Step1: Joint fit using gam()
  BigZb <- as.matrix(bdiag(rep(Zb, npc.y)))
  BigZ0 <- as.matrix(bdiag(rep(Z0, npc.y)))
  BigPx <- as.matrix(bdiag(rep(Px, npc.y)))
  BigPs <- as.matrix(bdiag(rep(Ps, npc.y)))
  fitb <- gam(psi.vec ~ (BigZb-1), paraPen = list(BigZb = list(BigPx, BigPs)), method = "REML")
  pred <- BigZ0%*%fitb$coefficients
  
  # Estimation / Prediction
  Yfitb = y.mu + matrix(fitb$fitted, ncol=npc.y)%*%t(y.efunc)
  Ypred = y.mu.test + matrix(pred, ncol=npc.y)%*%t(y.efunc)
  
  # Compute model-based prediction variance
  Resb = y.bs-Yfitb
  VarYp = model.Var(y.sm, Resb, fitb, Zb[[1]], Z0[[1]], pve.y)

  print(paste("Number of bootstrap iteration is", b))  
  result = list(Ypred = Ypred, VarYp = VarYp)
}

# Estimate Covariance matrix of response and its inverse:
G = function(y.sm){
  m_t = ncol(y.sm$Yhat)
  eval = y.sm$evalues; efunc = y.sm$efunctions; sig2 = y.sm$sigma2; npc.y = y.sm$npc
  if (npc.y == 1){ 
    G.tilde = eval*efunc%*%t(efunc)+sig2*diag(m_t)
    if (sig2 == 0){G.tilde.inv = 1/eval*efunc%*%t(efunc)}
    if (sig2 != 0){G.tilde.inv = diag(m_t)/sig2 - (efunc%*%solve(sig2/eval+t(efunc)%*%efunc)%*%t(efunc))/sig2
    }
  }
  if (npc.y > 1) { 
    G.tilde = efunc%*%diag(eval)%*%t(efunc)+sig2*diag(m_t)
    if (sig2 == 0){G.tilde.inv = efunc%*%diag(1/eval)%*%t(efunc)}
    if (sig2 != 0){G.tilde.inv = diag(m_t)/sig2 - (efunc%*%solve(diag(sig2/eval)+t(efunc)%*%efunc)%*%t(efunc))/sig2
    }
  }
  result = list(G.tilde = G.tilde, G.tilde.inv = G.tilde.inv)
}

# Compute Var(xi.tilde_p, xi.tilde_q); xi.tilde_p is the p-th predicted score of response
var.psi = function(y.sm, G.tilde.inv, p, q){
  m_t = ncol(y.sm$Yhat)
  eval = y.sm$evalues                 
  efunc = y.sm$efunctions
  npc = y.sm$npc
  if (npc == 1){vk = as.vector(eval*t(efunc)%*%G.tilde.inv%*%efunc*eval)}
  if (npc != 1){vk = as.vector(eval[p]*t(efunc[,p])%*%G.tilde.inv%*%efunc[,q]*eval[q])}
  vk
}

model.Var = function(y.sm, Resb, fitb, Zb, Z0, pve.y){
  n = nrow(Resb); m_t = ncol(Resb); ntest = nrow(Z0); npc = y.sm$npc
  sandwich = vcov(fitb, dispersion=1)[1:ncol(Zb),1:ncol(Zb)] # (Zb'Zb+P)^{-1}
  H0 = Z0%*%sandwich%*%t(Zb)                      				# ntest-by-n
  y.efunc = y.sm$efunctions           					# H0 = Z0(Zb'Zb+P)^{-1}Zb'; m_t-by-npc
  
  # Error Variance
  Res.sm = fpca.sc(Resb, pve=pve.y, var=TRUE)
  error.var = G(Res.sm)$G.tilde
  # Inverse of variance of marginal response
  G.tilde.inv = G(y.sm)$G.tilde.inv

  # Variance estimation
  Uk0 = as.list(NULL); VarYp = 0
  for (k in 1:npc){
    Uk0[[k]] = matrix(outer(y.efunc[,k], H0, '*'), nrow= ntest*m_t, ncol=n)
    vk = var.psi(y.sm, G.tilde.inv, k, k)
    VarYp = VarYp + vk*rowSums(Uk0[[k]]*Uk0[[k]]) 			# n.test*m-by-1
  }
  
  # Covariance estimation
  if (npc != 1){
    cb = combn((1:npc),2)                         				# 2-by-()
    for (k in 1:ncol(cb)){
      c1 = cb[1,k]; c2 = cb[2,k]
      uk = var.psi(y.sm, G.tilde.inv, c1, c2)
      VarYp = VarYp + 2*uk*rowSums(Uk0[[c1]]*Uk0[[c2]])
    }
  }
  VarYp = rep(diag(error.var), ntest) + VarYp 				# n*m_t-by-1
  VarYp
}

ACP = function(resp, yhat, Var.est, alpha){
  Var.est.mat = matrix(Var.est, nrow= nrow(resp), ncol=ncol(resp), byrow=TRUE)
  StdF.mat = sqrt(Var.est.mat)
  MOE = qnorm(1-alpha/2)*StdF.mat       				# margin of error
  llim = yhat-MOE                       					# lower limit
  ulim = yhat+MOE  						          	# upper limit
  Logic = (llim<resp) & (resp<ulim)
  cp = mean(rowMeans(Logic, na.rm=TRUE))
  cp
}