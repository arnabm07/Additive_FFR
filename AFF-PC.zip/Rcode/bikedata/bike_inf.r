######################################################
# bike_inf.r - Nov/05/2016				#
# Script created by Janet Kim              	          	#
#@multAFF.r:                                         		#
# main function used to perform prediction inference. 	#
# @multAFF_bs.r                                       		#
# ancillary function used for each bootstrap sample.  	#
######################################################

multAFF = function(y, w, w2, pve.x, pve.y, nbasis, testdata, B){
  n = nrow(y); m_t = ncol(y); m_s = ncol(w); ntest = nrow(testdata$Yfull)
  s = seq(0, 1, len=m_s)
  srep.test = matrix(rep(s,ntest), nrow=ntest, byrow=TRUE)  	# ntest-by-m_s
  t = seq(0, 1, len=m_t)
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions 				            	# m_t-by-npc.y
  psi = y.sm$scores; psi.vec = as.vector(psi); psi_k = psi[,1]
  npc = y.sm$npc

  # Smooth covariate
  w.sm = fpca.sc(w, pve=pve.x, var=TRUE)
  xtest.sm = fpca.sc(w, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat
  w.eval = w.sm$evalues; w.efunc = w.sm$efunctions
  
  # Peform transformation of covariate
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu , scale = sqrt(sig2.hat))
  wtest = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat)) 
  
  # Step0: Pre-fit
  prefit <- fgam(psi_k ~ 0+ af(X = xhat.tr, basistype = "te", presmooth = FALSE, Qtransform = FALSE,
                               splinepars = list(k = nbasis)) + w2,
                 method = "REML")
  Z = Px = Ps = as.list(NULL)
  Z[[1]] <- model.matrix(prefit)
  Px[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[1]]))
  Ps[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[2]]))
  
  # Obtain Design matrix for the test data
  Z0 = as.list(NULL)
  L.tr = prefit$fgam$ft[[1]]$L; L.test = L.tr[(1:ntest),]
  Z0[[1]] <- predict.gam(prefit, 
                         newdata=list(xhat.tr.omat = wtest, xhat.tr.tmat = srep.test, L.xhat.tr= L.test, w2 = testdata$Wfull2), 
                         type="lpmatrix")
  
  # Step1: Joint fit using gam()
  BigZ <- as.matrix(bdiag(rep(Z, y.sm$npc)))
  BigZ0 <- as.matrix(bdiag(rep(Z0, y.sm$npc)))
  BigPx <- as.matrix(bdiag(rep(Px, y.sm$npc)))
  BigPs <- as.matrix(bdiag(rep(Ps, y.sm$npc)))
  fit <- gam(psi.vec ~ (BigZ-1), paraPen=list(BigZ=list(BigPx, BigPs)), method = "REML") 
  pred <- BigZ0%*%fit$coefficients
  
  # Estimation / Prediction
  fit.mat = matrix(fit$fitted.values, ncol=y.sm$npc)
  pred.mat = matrix(pred, ncol=y.sm$npc)
  my <- colMeans(y, na.rm = TRUE)
  y.mu = fitted(gam(my ~ y.efunc))
  Yfit = matrix(y.mu, nrow=n, ncol=m_t, byrow=TRUE) + fit.mat%*%t(y.efunc)
  Ypred = matrix(y.mu, nrow=ntest, ncol=m_t, byrow=TRUE) + pred.mat%*%t(y.efunc)
  
  # Estimation Variance: apply boostrap procedure
  BSdata = BS.datagen(y=y, w=w, w2=w2, B)
  BSfit = lapply(c(1:B), function(l) multAFF_bs(BSdata$y.bs[[l]], BSdata$w.bs[[l]], BSdata$w2.bs[[l]],
                                                pve.x = pve.x, pve.y = pve.y, nbasis = nbasis, testdata))
  BS.VarYp = Reduce('+', lapply(c(1:B), function (l) BSfit[[l]]$VarYp))/B
  
  # Apply iterated expectations and variance formula
  bias0 = NULL
  for (l in 1:B) { bias0 = cbind(bias0, as.vector(t(Ypred - BSfit[[l]]$Ypred))) }
  VarYp = BS.VarYp + apply(bias0, 1, var)   # ntest*m_t-by-1
  
  # ACPp for predicted response:
  ACPp85 = ACP(testdata$Yfull, Ypred, VarYp, 0.15)
  ACPp90 = ACP(testdata$Yfull, Ypred, VarYp, 0.10)
  ACPp95 = ACP(testdata$Yfull, Ypred, VarYp, 0.05)
  ACPp = c(ACPp85, ACPp90, ACPp95)
  
  result = list(Yfit = Yfit, Ypred = Ypred, BSfit = BSfit, VarYp = VarYp, ACPp = ACPp)
}

multAFF_bs = function(y.bs, w.bs, w2.bs, pve.x, pve.y, nbasis, testdata){
  n = nrow(y.bs); m_t = ncol(y.bs); m_s = ncol(w.bs); ntest = nrow(testdata$Yfull)
  s = seq(0, 1, len=m_s)
  srep = matrix(rep(s,n), nrow=n, byrow=TRUE)               		# n-by-m_s
  srep.test = matrix(rep(s,ntest), nrow=ntest, byrow=TRUE)  # ntest-by-m_s
  t = seq(0, 1, len=m_t)
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions 				            	# m_t-by-npc.y
  psi = y.sm$scores; psi.vec = as.vector(psi); psi_k = psi[,1]
  npc = y.sm$npc
  
  # Smooth covariate
  w.sm = fpca.sc(w.bs, pve=pve.x, var=TRUE)
  w.eval = w.sm$evalues; w.efunc = w.sm$efunctions
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu, scale = sqrt(sig2.hat))
  
  # Peform transformation on test data set
  xtest.sm = fpca.sc(w.bs, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat
  xtest.sm.tr = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat))  
  
  prefit <- fgam(psi_k ~ 0 + af(X = xhat.tr, basistype = "te", presmooth = FALSE, Qtransform = FALSE,
                             		splinepars = list(k = nbasis)) + w2.bs, method = "REML")
  Zb = Px = Ps = as.list(NULL)
  Zb[[1]] <- model.matrix(prefit)
  Px[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[1]]))
  Ps[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[2]]))
  
  # Obtain Design matrix for the test data
  Z0 = as.list(NULL)
  L.test = prefit$fgam$ft[[1]]$L[(1:ntest),]                 		# ntest-by-m_s
  Z0[[1]] <- predict.gam(prefit, newdata=list(xhat.tr.omat = xtest.sm.tr, 
                                              xhat.tr.tmat = srep.test, 
                                              L.xhat.tr= L.test,
                                              w2.bs = testdata$Wfull2), 
                         type="lpmatrix")
  
  # Step1: Joint fit using gam()
  BigZb <- as.matrix(bdiag(rep(Zb, npc)))
  BigZ0 <- as.matrix(bdiag(rep(Z0, npc)))
  BigPx <- as.matrix(bdiag(rep(Px, npc)))
  BigPs <- as.matrix(bdiag(rep(Ps, npc)))
  
  fitb <- gam(psi.vec ~ (BigZb-1),  paraPen = list(BigZb = list(BigPx, BigPs)), method = "REML")
  pred <- BigZ0%*%fitb$coefficients                 			# ntest*npc-by-1
  
  # Estimation / Prediction
  fitb.mat = matrix(fitb$fitted, ncol=npc)          			# n-by-npc
  pred.mat = matrix(pred, ncol=npc)                 			# ntest-by-npc
  my <- colMeans(y, na.rm = TRUE)
  y.mu = fitted(gam(my ~ y.efunc))
  Yfitb = matrix(y.mu, nrow=n, ncol=m_t, byrow=TRUE) + fitb.mat%*%t(y.efunc)
  Ypred = matrix(y.mu, nrow=ntest, ncol=m_t, byrow=TRUE) + pred.mat%*%t(y.efunc)
  
  # Estimation Variance by bootstrapping
  Resb = y-Yfitb
  VarYp = model.Var(y.sm, Resb, fitb, Zb[[1]], Z0[[1]], pve.y)
  result = list(Ypred = Ypred, Yfitb = Yfitb, VarYp = VarYp)
}


# Perform bootstrap inference!
library(refund); library(mgcv); library(Matrix)
load("bike.RData"); source("datagenALL.r"); source("AFFinf.r")
set.seed(9300)
ntrue = 105; n = 89; ntest = 16; m_s = m_t = 24
ind.n = sample(c(1:ntrue), n, replace = FALSE)
hum.avg.c = (hum.avg-mean(hum.avg))/sd(hum.avg)
y <- log(yfull[ind.n,]+1); w <- wfull[ind.n, ]; w2 <- hum.avg.c[ind.n]
ytest <- log(yfull[-ind.n, ]+1); xtest <- wfull[-ind.n, ]; xtest2 <- hum.avg.c[-ind.n]
newdata = list(Yfull = ytest, Wfull = xtest, Wfull2 = xtest2)

fit <- multAFF(y, w, w2, pve.x=0.99, pve.y=0.95, nbasis = c(7,7), testdata=newdata, B=1000)
ACPp = fit$ACPp


# Obtain point-wise prediction interval
tgrid=c(0:23)
Var.est = matrix(fit$VarYp, nrow= ntest, ncol=m_t, byrow=TRUE)
MOE = qnorm(1-0.05/2)*sqrt(Var.est)
llim = fit$Ypred-MOE; ulim = fit$Ypred+MOE

setEPS()
postscript("bikeband.eps", width=10, height=4)
#pdf("bikeband.pdf", width=10, height=4)
par(mfrow=c(1,3))
i=1
plot(tgrid, ytest[i,], xlab="Hour", ylab="log(1+Count)", ylim=c(-3,8.5), pch=20)
lines(tgrid, fit$Ypred[i,], lwd=1.5)
lines(tgrid, llim[i,], lty="dashed", lwd=1.5)
lines(tgrid, ulim[i,], lty="dashed", lwd=1.5)
legend(0.6, -2, c("Observed", "Predicted"), lty=c(NA, "solid"), pch=c(20, NA), horiz=TRUE)
i=10
plot(tgrid, ytest[i,], xlab="Hour", ylab="log(1+Count)", ylim=c(-3,8.5), pch=20)
lines(tgrid, fit$Ypred[i,], lwd=1.5)
lines(tgrid, llim[i,], lty="dashed", lwd=1.5)
lines(tgrid, ulim[i,], lty="dashed", lwd=1.5)
legend(0.6, -2, c("Observed", "Predicted"), lty=c(NA, "solid"), pch=c(20, NA), horiz=TRUE)
i=15
plot(tgrid, ytest[i,], xlab="Hour", ylab="log(1+Count)", ylim=c(-3,8.5), pch=20)
lines(tgrid, fit$Ypred[i,], lwd=1.5)
lines(tgrid, llim[i,], lty="dashed", lwd=1.5)
lines(tgrid, ulim[i,], lty="dashed", lwd=1.5)
legend(0.6, -2, c("Observed", "Predicted"), lty=c(NA, "solid"), pch=c(20, NA), horiz=TRUE)
dev.off()