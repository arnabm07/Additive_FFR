rm(list=ls())
library(Matrix); library(refund); library(mgcv)
load("bike.RData")

set.seed(9300)
ntrue = 105; n = 89; ntest = 16; m_s = m_t = 24
ind.n = sample(c(1:ntrue), n, replace = FALSE)
hum.avg.c = (hum.avg-mean(hum.avg))/sd(hum.avg)
y <- log(yfull[ind.n,]+1); w <- wfull[ind.n, ]; w2 <- hum.avg.c[ind.n]
ytest <- log(yfull[-ind.n, ]+1); xtest <- wfull[-ind.n, ]; xtest2 <- hum.avg.c[-ind.n]

################# Transformation of covariate
s = seq(0, 1, len=m_s); t = seq(0, 1, len=m_t)

# Smooth response and obtain FPC scores
y.sm = fpca.sc(y, pve=0.95, var=TRUE)
y.efunc = y.sm$efunctions
psi = y.sm$scores; psi.vec = as.vector(psi); psi_k = psi[,1]
npc = y.sm$npc  

# Smooth covariate
w.sm = fpca.sc(w, pve=0.99, var=TRUE)
w.eval = w.sm$evalues; w.efunc = w.sm$efunctions
if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }        # m_s-by-1
if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) } # m_s-by-1
xhat.tr = scale(w.sm$Yhat, center =  w.sm$mu, scale = sqrt(sig2.hat))           # n-by-m_s

srep = matrix(s, nrow=n, ncol=m_s, byrow=TRUE)  # ntest-by-m_s
L = matrix(1/m_s, n, m_s)
gsize = 24
xgrid = seq(-1.6, 1.6, l=gsize); tgrid = seq(0,1,l=gsize)
truesurfevals = as.list(NULL)
for (k in 1:npc){
  psi_k <- psi[,k]
  fit <- gam(psi_k ~ 0 + te(xhat.tr, srep, by=L, k=c(7,7), bs='ps', m=c(2,2))+w2,
             method="REML")
  
  truesurfevals[[k]]=matrix(nr=gsize,nc=gsize)
  for(i in 1:gsize){
    newd <- data.frame(xhat.tr = rep(xgrid[i],gsize), srep = tgrid, L = rep(1,gsize), w2=0)
    lpmat <- predict(fit, newd, type="lpmatrix")
    truesurfevals[[k]][i,] <- lpmat%*%coef(fit) 	
  }
}
ind0 <- 1; ind1 <-13; ind2 <-21
surf0 = surf1 = surf2 = 0
for (k in 1:npc){
  surf0 <- surf0 + truesurfevals[[k]]*y.efunc[ind0,k]
  surf1 <- surf1 + truesurfevals[[k]]*y.efunc[ind1,k]
  surf2 <- surf2 + truesurfevals[[k]]*y.efunc[ind2,k]
}
tgrid2 <- seq(0, 23, len=gsize)

library(gridExtra); library(lattice)
setEPS()
postscript("BikeHumlevel_color1.eps")
#pdf("BikeHumlevel_color1.pdf")
plot1 <- levelplot(t(surf0), contour=TRUE, ylim=range(tgrid2), xlim=range(xgrid), labels=TRUE, 
                   row.values = xgrid, column.values = tgrid2,
                   colorkey=list(space="right"), at=seq(-12,12,length=21),
                   # Color #
                   col.regions = heat.colors(50, 1),
                   # Label #
                   ylab=list(label="Hour (s)", cex=1.3), 
                   xlab=list(label="Temperature (x)", cex=1.3), 
                   main = list(label="t=0", cex=1.3)
)
print(plot1, panel.width = list(120, "mm"))
dev.off()


setEPS()
postscript("BikeHumlevel_color2.eps")
#pdf("BikeHumlevel_color2.pdf")
plot2 <- levelplot(t(surf1), contour=TRUE, ylim=range(tgrid2), xlim=range(xgrid), labels=TRUE,
                   row.values = xgrid, column.values = tgrid2,
                   colorkey=list(space="right"), at=seq(-12,12,length=21), 
                   # Color #
                   col.regions = heat.colors(50, 1),
                   # Label #
                   ylab=list(label="Hour (s)", cex=1.3),
                   xlab=list(label="Temperature (x)", cex=1.3),
                   main = list(label="t=12", cex=1.3)
)          
print(plot2, panel.width = list(120, "mm"))
dev.off()


setEPS()
postscript("BikeHumlevel_color3.eps")
#pdf("BikeHumlevel_color3.pdf")
plot3 <- levelplot(t(surf2), contour=TRUE, ylim=range(tgrid2), xlim=range(xgrid), labels=TRUE,
                   row.values = xgrid, column.values = tgrid2, 
                   colorkey=list(space="right"), at=seq(-12,12,length=21), 
                   # Color #
                   col.regions = heat.colors(50, 1),
                   
                   # Label #
                   ylab=list(label="Hour (s)", cex=1.3),
                   xlab=list(label="Temperature (x)", cex=1.3),
                   main = list(label="t=20", cex=1.3)
)
print(plot3, panel.width = list(120, "mm"))
dev.off()