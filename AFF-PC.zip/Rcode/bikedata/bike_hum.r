######################################################
# bike_hum.r - Nov/06/2016				 #
# Script created by Janet Kim			 #
# Contents:					 #
# Regress log(1+count) on temperature and avg. humidity. #
#######################################################
library(Matrix); library(refund); library(mgcv)
load("bike.RData")

set.seed(9300)
ntrue = 105; n = 89; ntest = 16; m_s = m_t = 24
ind.n = sample(c(1:ntrue), n, replace = FALSE)
hum.avg.c = (hum.avg-mean(hum.avg))/sd(hum.avg)
y <- log(yfull[ind.n,]+1); w <- wfull[ind.n, ]; w2 <- hum.avg.c[ind.n]
ytest <- log(yfull[-ind.n, ]+1); xtest <- wfull[-ind.n, ]; xtest2 <- hum.avg.c[-ind.n]
newdata = list(Yfull = ytest, Wfull = xtest, Wfull2 = xtest2)


multAFF = function(y, w, w2, pve.x, pve.y, nbasis, fit_opt = "nonlinear", testdata){
  n = nrow(y); m_t = ncol(y); m_s = ncol(w); ntest = nrow(testdata$Yfull)
  s = seq(0, 1, len=m_s); t = seq(0, 1, len=m_t)
  srep.test = matrix(s, nrow=ntest, ncol=m_s, byrow=TRUE)  # ntest-by-m_s
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions 				            # m_t-by-npc.y
  psi = y.sm$scores                             # n-by-npc.y
  psi.vec = as.vector(psi)                      # n*npc.y-by-1
  psi_k = psi[,1]                               # n-by-1; used in Step0
  
  # Smooth covariate
  w.sm = fpca.sc(w, pve=pve.x, var=TRUE)
  xtest.sm = fpca.sc(w, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat
  w.eval = w.sm$evalues
  w.efunc = w.sm$efunctions
  
  # Peform transformation of covariate
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }        	# m_s-by-1
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu , scale = sqrt(sig2.hat))	# n-by-m_s
  wtest = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat)) 
  
  prefit <- NULL
  if (fit_opt == "AFF-PC"){
    prefit <- fgam(psi_k ~ 0+ af(X = xhat.tr, basistype = "te", presmooth = FALSE, Qtransform = FALSE,
                                 	 splinepars = list(k = nbasis)) + w2,
                          method = "REML")
    Z = Px = Ps = as.list(NULL)
    Z[[1]] <- model.matrix(prefit)
    Px[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[1]]))
    Ps[[1]] <- rbind(0, cbind(0, prefit$smooth[[1]]$S[[2]]))
    
    # Obtain Design matrix for the test data
    Z0 = as.list(NULL)
    L.tr = prefit$fgam$ft[[1]]$L; L.test = L.tr[(1:ntest),]
    Z0[[1]] <- predict.gam(prefit, 
                           newdata=list(xhat.tr.omat = wtest, xhat.tr.tmat = srep.test, L.xhat.tr= L.test, w2 = testdata$Wfull2), 
                           type="lpmatrix")
    
    # Step1: Joint fit using gam()
    BigZ <- as.matrix(bdiag(rep(Z, y.sm$npc)))
    BigZ0 <- as.matrix(bdiag(rep(Z0, y.sm$npc)))
    BigPx <- as.matrix(bdiag(rep(Px, y.sm$npc)))
    BigPs <- as.matrix(bdiag(rep(Ps, y.sm$npc)))
    fit <- gam(psi.vec ~ (BigZ-1), paraPen=list(BigZ=list(BigPx, BigPs)), method = "REML") 
    pred <- BigZ0%*%fit$coefficients
    
    # Estimation / Prediction
    fit.mat = matrix(fit$fitted.values, ncol=y.sm$npc)
    pred.mat = matrix(pred, ncol=y.sm$npc)
    
    my <- colMeans(y, na.rm = TRUE)
    y.mu = fitted(gam(my ~ y.efunc))
    Yfit = matrix(y.mu, nrow=n, ncol=m_t, byrow=TRUE) + fit.mat%*%t(y.efunc)
    Ypred = matrix(y.mu, nrow=ntest, ncol=m_t, byrow=TRUE) + pred.mat%*%t(y.efunc)
    Res = na.omit(as.vector(t(y - Yfit)))
  }
  if (fit_opt == "FLM"){# FLM
    fit <- pffr(y ~ ff(xhat.tr, xind = s, splinepars = list(bs = "ps", m = list(c(2, 2), c(2, 2)), k=nbasis),
                            check.ident = FALSE) + w2,
                   bs.int = list(bs = "ps", k = 7, m = c(2, 2)),
                   method="REML")
    # Estimation / Prediction
    Yfit = predict(fit)
    Ypred <- predict(fit, newdata=list(xhat.tr = wtest, w2 = testdata$Wfull2))
    Res = na.omit(as.vector(t(y-Yfit)))
  }
  if (fit_opt == "AFF-S"){
    fit <- pffr(y ~ sff(xhat.tr, xind = s, splinepars = list(m = c(2,2,2), k = nbasis)) + w2,
                   bs.int = list(bs = "ps", k = 7, m = c(2, 2)),
                   method="REML")
    # Estimation / Prediction
    Yfit = predict(fit)          					# n-by-m_t
    Ypred <- predict(fit, newdata=list(xhat.tr = wtest, w2 = testdata$Wfull2))  	# ntest-by-m_t    
    Res = na.omit(as.vector(t(y-Yfit)))
  }
  # RMSPE
  RMSPE_in = sqrt(mean(Res^2))
  RMSPE_out = sqrt(mean((testdata$Yfull-Ypred)^2))
  result = list(fit=fit, prefit=prefit, 
                Yfit = Yfit, Ypred = Ypred, RMSPE_in = RMSPE_in, RMSPE_out = RMSPE_out)
}

# Fit AFF-PC:
affpc = multAFF(y, w, w2, pve.x=0.99, pve.y=0.95, nbasis=c(7,7), fit_opt="AFF-PC", testdata=newdata)
affpc_est = affpc$Yfit   # fitted curves from training data
affpc_pred = affpc$Ypred # predcted curvees from test data

# Fit AFF-S:
affs <- multAFF(y, w, w2, pve.x=0.99, pve.y=0.95, nbasis=c(7,7), fit_opt="AFF-S", testdata=newdata)
affs_est = affpc$Yfit   # fitted curves from training data
affs_pred = affpc$Ypred # predcted curvees from test data

# Fit FLM:
flm <- multAFF(y, w, w2, pve.x=0.99, pve.y=0.95, nbasis = 7, fit_opt="FLM", testdata=newdata)
flm_est = affpc$Yfit   # fitted curves from training data
flm_pred = affpc$Ypred # predcted curvees from test data


#################
# Visualization #
#################
matplot(0:23, t(yfull), type="l", lty="solid", col="darkgrey", lwd=1.5, ylim=c(0, 430),
        xlab="Hour", ylab="Count", main="Number of casual bike users on Saturday",
        cex.main=0.85, cex.lab=0.9, cex.axis=0.9)
lines(0:23, yfull[2,], lty="solid", lwd=2)
lines(0:23, yfull[18,], lty="dashed", lwd=2)
lines(0:23, yfull[30,], lty="dotted", lwd=4)
legend(0.55, 430, c("Jan 8", "Apr 30", "Jul 23"), lty=c("solid", "dashed", "dotted"), 
       pt.cex=0.8, cex=0.8, horiz=TRUE)

matplot(0:23, t(wfull), type="l", lty="solid", col="darkgrey", lwd=1.5, ylim=c(-10,50),
        xlab="Hour", ylab="Temperature", main="Hourly temperature on Saturday",
        cex.main=0.85, cex.lab=0.9, cex.axis=0.9)
lines(0:23, wfull[2,], lty="solid", lwd=2)
lines(0:23, wfull[18,], lty="dashed", lwd=2)
lines(0:23, wfull[30,], lty="dotted", lwd=4)
legend(0.55, 50, c("Jan 8", "Apr 30", "Jul 23"), lty=c("solid", "dashed", "dotted"), 
       pt.cex=0.8, cex=0.8, horiz=TRUE)

# Estimated marginal response
y.sm = fpca.sc(y, pve=0.95, var=TRUE)
y.efunc = y.sm$efunctions
my = colMeans(y, na.rm = TRUE)
y.mu = fitted(gam(my ~ y.efunc))
plot(0:23, y.mu, type="l", xlab="", ylab=expression(hat(alpha)(t)))

# Estimated gamma(t); i.e., estimated effect of the average humidity
ind.hum = c(0:(y.sm$npc-1))*length(affpc$prefit$coefficients)+1 # 1, 50, 99
gmahat = y.efunc%*%affpc$fit$coefficients[ind.hum]
plot(0:23, gmahat, type="l", xlab="", ylab=expression(hat(gamma)(t)))