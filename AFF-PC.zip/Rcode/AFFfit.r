######################################################
# AFF.r - Nov/05/2016				#
# Script created by Janet Kim              		#
#						#
# @ Sample size in training data:			#
#   n subjects					#
#   m_s observation points per subject for covariate 	#
#   m_t observation points per subject for response 	#
# @ Sample size in test data:				#
#   ntest subjects					#
#   m_s observation points per subject for covariate 	#
#   m_t observation points per subject for response 	#
######################################################

AFF = function(y, w, pve.x, pve.y, nbasis, fit_opt = "AFF-PC", testdata){
  n = nrow(y); m_t = ncol(y); m_s = ncol(w); ntest = nrow(testdata$Wfull)
  s = seq(0, 1, len=m_s);  srep.test = matrix(s, nrow=ntest, ncol=m_s, byrow=TRUE) 
  
  # Smooth response and obtain FPC scores
  y.sm = fpca.sc(y, pve=pve.y, var=TRUE)
  y.efunc = y.sm$efunctions    					# m_t-by-npc.y
  psi = y.sm$scores                   					# n-by-npc.y
  y.mu.mat = matrix(y.sm$mu, nrow=n, ncol=m_t, byrow=TRUE)		# n-by-m_t
  y.mu.mattest = matrix(y.sm$mu, nrow=ntest, ncol=m_t, byrow=TRUE)	# ntest-by-m_t
  psi.vec = as.vector(psi)                      				# n*npc.y-by-1
  psi_k = psi[,1]                               					# n-by-1; used in Step0
  npc.y = y.sm$npc  
  ytilde = y-y.mu.mat                           				# centered
  
  # Smooth covariate
  w.sm = fpca.sc(w, pve=pve.x, var=TRUE)          			# training data; n-by-m_s
  xtest.sm = fpca.sc(w, Y.pred=testdata$Wfull, pve=pve.x, var=TRUE)$Yhat 	# test data; ntest-by-m_s
  w.eval = w.sm$evalues                     					# npc.x-by-1
  w.efunc = w.sm$efunctions        					# m_s-by-npc.x
  
  # Peform transformation of covariate
  if (length(w.eval) == 1){ sig2.hat = diag(w.eval*w.efunc%*%t(w.efunc)) }        	# m_s-by-1
  if (length(w.eval) > 1){ sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc)) }
  xhat.tr = scale(w.sm$Yhat, center = w.sm$mu , scale = sqrt(sig2.hat))	# n-by-m_s
  wtest = scale(xtest.sm, center = w.sm$mu, scale = sqrt(sig2.hat))  
  
  if (fit_opt == "AFF-PC"){
    # Step0: Pre-fit 
    prefit <- fgam(psi_k ~ 0+af(X = xhat.tr, 
                                basistype = "te", presmooth = FALSE, Qtransform = FALSE, 
                                splinepars = list(k = nbasis)),
                           method = "REML")
    Z = Px = Ps = as.list(NULL)
    Z[[1]] <- model.matrix(prefit)
    Px[[1]] <- prefit$smooth[[1]]$S[[1]]; Ps[[1]] <- prefit$smooth[[1]]$S[[2]]
    
    # Obtain Design matrix for the test data
    Z0 = as.list(NULL)    
    L.test = matrix(prefit$fgam$ft[[1]]$L[1,], nrow=ntest, ncol=m_s, byrow=TRUE)
    Z0[[1]] <- predict.gam(prefit, 
                           	         newdata=list(xhat.tr.omat = wtest, xhat.tr.tmat = srep.test, L.xhat.tr= L.test), 
                           	         type="lpmatrix")
 
    # Step1: Joint fit using gam()
    BigZ <- as.matrix(bdiag(rep(Z, npc.y)))
    BigZ0 <- as.matrix(bdiag(rep(Z0, npc.y)))
    BigPx <- as.matrix(bdiag(rep(Px, npc.y)))
    BigPs <- as.matrix(bdiag(rep(Ps, npc.y))) 
    fit <- gam(psi.vec ~ (BigZ-1), paraPen=list(BigZ=list(BigPx, BigPs)), method = "REML")      
    pred <- BigZ0%*%fit$coefficients
    
    # Estimation / Prediction
    Yfit = y.mu.mat + matrix(fit$fitted.values, ncol=npc.y)%*%t(y.efunc)        	# n-by-m_t
    Ypred = y.mu.mattest + matrix(pred, ncol=npc.y)%*%t(y.efunc)  		# ntest-by-m_t
    Res = na.omit(as.vector(t(y - Yfit)))					
  }
  if (fit_opt == "FLM"){# FLM
    fit <- pffr(ytilde ~ 0 + 
                  ff(xhat.tr, splinepars = list(m = list(c(2, 2), c(2, 2)), k=nbasis), check.ident = FALSE),
                    method="REML")
    # Estimation / Prediction
    Yfit = y.mu.mat + predict(fit)         					# n-by-m_t
    Ypred <- y.mu.mattest + predict(fit, newdata=list(xhat.tr = wtest))  	# ntest-by-m_t    
    Res = na.omit(as.vector(t(y-Yfit)))
  }
if (fit_opt == "AFF-S"){
    fit <- pffr(ytilde ~ 0 + sff(xhat.tr, splinepars = list(m = c(2,2,2), k = nbasis)),
                    method="REML")
    # Estimation / Prediction
    Yfit = y.mu.mat + predict(fit)          					# n-by-m_t
    Ypred <- y.mu.mattest + predict(fit, newdata=list(xhat.tr = wtest))  	# ntest-by-m_t    
    Res = na.omit(as.vector(t(y-Yfit)))
  }

  # RMSPE
  RMSPE_in = sqrt(mean(Res^2))
  if (is.null(testdata$Yfull)){ RMSPE_out = sqrt(mean((testdata$Ytrue-Ypred)^2)) }
  if (is.null(testdata$Ytrue)){ RMSPE_out = sqrt(mean((testdata$Yfull-Ypred)^2)) }
  
  result = list(Yfit = Yfit, Ypred = Ypred, RMSPE_in = RMSPE_in, RMSPE_out = RMSPE_out)
}